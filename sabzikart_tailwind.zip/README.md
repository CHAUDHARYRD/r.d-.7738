# SabziKart - Vite + React + Tailwind (Supabase-ready)

## Quick start

1. Copy `.env.example` → `.env.local` and set Supabase URL + Anon Key.
2. Install dependencies:
   ```bash
   npm install
   ```
3. Run dev server:
   ```bash
   npm run dev
   ```
4. Open `http://localhost:5173`

### Deploy on Vercel
- Framework: Vite
- Build Command: `npm run build`
- Output Directory: `dist`
- Set environment variables in Vercel settings.
